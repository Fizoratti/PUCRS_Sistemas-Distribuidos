import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;

public class NotasClient {

	public static void main(String[] args) throws IOException {
		if	(args.length != 2) {
			System.out.println("Uso: java NotasClient <maquina> <nome> <numero>");
			System.exit(1);
		}
		// cria um socket datagrama
		DatagramSocket socket = new DatagramSocket();
		// envia um pacote
		byte[] numero = new byte[256];
		numero = args[1].getBytes();
		InetAddress servIP = InetAddress.getByName(args[0]);
		DatagramPacket pacEnv = new DatagramPacket(numero, numero.length, servIP, 0x8003);
		socket.send(pacEnv);
		// obtem a resposta
		byte[] bufNota = new byte[8];
		DatagramPacket pacRec = new DatagramPacket(bufNota, bufNota.length);
		socket.receive(pacRec);
		// mostra a resposta
		System.out.println("Numero ("+numero+") fatorial '"+args[1]+"' = "+ByteBuffer.wrap(bufNota).getDouble());
		// fecha o socket
		socket.close();
	}

}
