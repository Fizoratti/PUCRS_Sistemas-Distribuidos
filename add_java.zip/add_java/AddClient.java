import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;

public class AddClient {

	public static void main(String[] args) throws IOException {
		if	(args.length != 3) {
			System.out.println("Uso: java AddClient <maquina> <numero1> <numero2>");
			System.exit(1);
		}
		// cria um socket datagrama
		DatagramSocket socket = new DatagramSocket();
		// envia um pacote
		String data = args[1] + " " + args[2];
		byte[] nums = new byte[1024];
		nums = data.getBytes();
		InetAddress serv_ip = InetAddress.getByName(args[0]);
		DatagramPacket output = new DatagramPacket(nums, nums.length, serv_ip, 30000);
		socket.send(output);
		// obtem a resposta
		byte[] res = new byte[1024];
		try {
			DatagramPacket input = new DatagramPacket(res, res.length);
			socket.setSoTimeout(1000);
			socket.receive(input);
			// mostra a resposta
			System.out.println("Resultado: " + ByteBuffer.wrap(res).getInt());

			// envia um pacote
			String dataAck = "Ack";
			byte[] ack = new byte[1024];
			ack = dataAck.getBytes();
			DatagramPacket outputAck = new DatagramPacket(ack, ack.length, serv_ip, 30000);
			socket.send(outputAck);
			// obtem a resposta
		} catch	(IOException e) {
			System.out.println("Servidor offline.");
		}
		// fecha o socket
		socket.close();
	}

}
