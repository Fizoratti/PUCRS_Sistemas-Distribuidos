import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;

public class AddServer {
	public static void main(String[] args) throws IOException {
		DatagramSocket socket	= new DatagramSocket(30000);
		byte[] buff_in	= new byte[1024];
		byte[] buff_out	= new byte[1024];
		byte[] buff_inAck	= new byte[1024];
		byte[] buff_outAck	= new byte[1024];

		while (true) {
			try {
				// receive()
				DatagramPacket input = new DatagramPacket(buff_in, buff_in.length);
				socket.setSoTimeout(0);
				socket.receive(input);

				String message = new String(input.getData(), 0, input.getLength());

				String vars[] = message.split("\\s");
				int sum = Integer.parseInt(vars[0]) + Integer.parseInt(vars[1]);

				ByteBuffer.wrap(buff_out).putInt(sum);

				InetAddress resp_ip = input.getAddress();
				int resp_port = input.getPort();

				int timeoutCount = 0;

				do {
					try {
						// send()
						DatagramPacket output = new DatagramPacket(buff_outAck, buff_outAck.length, resp_ip, resp_port);
						socket.send(output);

						//receiveAck()
						DatagramPacket inputAck = new DatagramPacket(buff_inAck, buff_inAck.length);
						socket.setSoTimeout(1000);
						socket.receive(inputAck);

						String messageAck = new String(inputAck.getData(), 0, inputAck.getLength());

						if (messageAck == "Ack") {
							// mostra a resposta
							System.out.println("Ack recebido");
						} 
					} catch	(IOException e) {
						System.out.println("Ack "+timeoutCount+" nao recebido");
						timeoutCount++;
					}
				} while (timeoutCount <3);
				

				// int sumAck = Integer.parseInt(varsAck[0]) + Integer.parseInt(varsAck[1]);

				// ByteBuffer.wrap(buff_outAck).putInt(sumAck);

				// InetAddress resp_ipAck = inputAck.getAddress();
				// int resp_portAck = inputAck.getPort();
				// DatagramPacket outputAck = new DatagramPacket(buff_outAck, buff_outAck.length, resp_ipAck, resp_portAck);


			} catch	(IOException e) {
				e.printStackTrace();
				break;
			}
		}
		socket.close();
	}

}
